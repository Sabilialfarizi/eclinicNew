

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">
            <?php if(request()->is('admin/price-product*')): ?>
            Edit Harga Produk
            <?php else: ?>
            Edit Harga Service
            <?php endif; ?>
        </h4>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-sm-6">
        <form action="/admin/price/<?php echo e($price->id); ?>/update" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('admin.harga-product.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="m-t-20 text-center">
                <button type="submit" class="btn btn-primary submit-btn">Update</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Harga Produk'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/harga-product/edit.blade.php ENDPATH**/ ?>