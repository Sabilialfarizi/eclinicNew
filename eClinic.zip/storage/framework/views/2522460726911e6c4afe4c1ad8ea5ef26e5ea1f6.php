

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4">
        <h1 class="page-title">Voucher</h1>
    </div>

    <div class="col-sm-8 text-right m-b-20">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voucher-create')): ?>
        <a href="<?php echo e(route('admin.voucher.create')); ?>" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Voucher</a>
        <?php endif; ?>
    </div>
</div>

 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<div class="row">
    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table table-bordered table-striped custom-table datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Voucher</th>
                        <th>Mulai</th>
                        <th>Akhir</th>
                        <th>Min Trx</th>
                        <th>Min or Per</th>
                        <th>Nominal</th>
                        <th>Per (%)</th>
                        <th>Kuota</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($voucher->kode_voucher); ?></td>
                        <td><?php echo e($voucher->tgl_mulai); ?></td>
                        <td><?php echo e($voucher->tgl_akhir); ?></td>
                        <td>Rp. <?php echo number_format($voucher->min_transaksi, 0, ',', '.'); ?></td>
                        <td><?php echo e($voucher->type); ?></td>
                        <td>Rp. <?php echo number_format($voucher->nominal, 0, ',', '.'); ?></td>
                        <td><?php echo e($voucher->persentase); ?>%</td>
                        <td>
                            <?php if($voucher->is_active == 1): ?>
                            <span class="custom-badge status-green d-flex justify-content-between">
                                Available
                                <span><?php echo e($voucher->kuota); ?></span>
                            </span>
                            <?php else: ?>
                            <span class="custom-badge status-red d-flex justify-content-center text-center">
                                Used
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voucher-edit')): ?>
                            <a href="<?php echo e(route('admin.voucher.edit', $voucher->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voucher-delete')): ?>
                            <form action="<?php echo e(route('admin.voucher.destroy', $voucher->id)); ?>" method="post" style="display: inline;" class="delete-form">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Voucher'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/voucher/index.blade.php ENDPATH**/ ?>