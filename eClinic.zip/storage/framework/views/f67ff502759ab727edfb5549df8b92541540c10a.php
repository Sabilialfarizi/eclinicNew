<div class="row">
    <div class="col-md-12">
        <div class="dash-widget shadow">
            <div class="dash-widget-info pb-4">
                <h2>Jadwal Booking Appointment</h2>
            </div>
            <form action="<?php echo e(route('marketing.service.appointments.filter')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <div class="row filter-row">
                    <div class="col-sm-12 col-md-3">
                        <div class="form-group form-focus select-focus">
                            <label class="focus-label">Cabang</label>
                            <select class="select floating">
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                        <div class="form-group form-focus">
                            <label class="focus-label">From</label>
                            <div class="cal-icon">
                                <input id="startdate" name="startdate" class="form-control <?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> floating datetimepicker" type="text">
                                <?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="invalid-feedback"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                        <div class="form-group form-focus">
                            <label class="focus-label">To</label>
                            <div class="cal-icon">
                                <input id="enddate" name="enddate" class="form-control <?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> floating datetimepicker" type="text">
                                <?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="invalid-feedback"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                        <button type="submit" class="btn btn-success btn-block"> Cari Jadwal </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>
                <?php echo e($message); ?>

            </strong>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if($message = Session::get('error')): ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>
                <?php echo e($message); ?>

            </strong>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="row">
    <?php for($i = 0; $i <= $count;$i++): ?> <div class="col-sm-12 col-md-6">
        <div class="blog grid-blog shadow">
            <div class="blog-image">
                <h3><?php echo e($startdate->addDay(1)->format('d m Y')); ?> </h3>
            </div>
            <div class="blog-content">
                <div class="table-responsive">
                    <table class="table table-bordered border">
                        <tr>
                            <th>Detail</th>
                            <th>Status</th>
                            <th>Booking</th>
                        </tr>
                        <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $data->jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($row->tanggal == $startdate->format('Y-m-d')): ?>
                        <tr>
                            <td>
                                <p>
                                    <a href="<?php echo e(route('marketing.doctor.show',$row->id)); ?>"><span class="custom-badge status-blue"><?php echo e($row->user->name); ?></span></a>
                                </p>
                                <p>
                                    <?php if( $row->shift->kode == 'L'): ?>
                                    <span class="custom-badge status-red"><?php echo e($row->shift->kode); ?></span>
                                    <?php else: ?>
                                    <span class="custom-badge status-green"><?php echo e($row->shift->kode); ?></span>
                                    <?php endif; ?>
                                </p>
                                <p>
                                    <?php if( $row->shift->kode == 'L'): ?>
                                    <span class="custom-badge status-red">Libur</span>
                                    <?php else: ?>
                                <h6 class="text-secondary"><?php echo e($row->shift->waktu_mulai); ?> - <?php echo e($row->shift->waktu_selesai); ?></h6>
                                <?php endif; ?>
                                </p>
                            </td>
                            <td class="text-center">
                                <ul class="list-group">
                                    <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if( $row->tanggal == $book->tanggal_status): ?>
                                    <?php if($book->jam_status >= $row->shift->waktu_mulai && $book->jam_selesai <= $row->shift->waktu_selesai): ?>
                                        <?php if( $row->user->id == $book->dokter->id): ?>
                                        <li class="list-group-item">
                                            <a href="<?php echo e(route('marketing.appointments.show', $book->id)); ?>" class="btn btn-sm btn-outline-primary">
                                                <div class="col-md-12">
                                                    <?php echo e($book->no_booking); ?>

                                                </div>
                                                <div class="col-md-12">
                                                    <?php echo e($book->pasien->nama); ?>

                                                </div>
                                                <div class="col-md-12">
                                                    <?php echo e($book->jam_status); ?> - <?php echo e($book->jam_selesai); ?>

                                                </div>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td>
                                <?php if( $row->shift->kode == 'L'): ?>
                                <button disabled class="btn btn-outline-secondary take-btn">Holiday</button>
                                <?php else: ?>
                                <?php if( $row->tanggal == Carbon\Carbon::now()->format('Y-m-d')): ?>
                                <?php if(Carbon\Carbon::parse( $row->shift->waktu_selesai)->format('H:i:s') < Carbon\Carbon::now()->format('H:i:s')): ?>
                                    <button id="<?php echo e($row->id); ?>" title="<?php echo e($row->user->id); ?>" disabled class="btn btn-outline-secondary take-btn button-show" data-toggle="modal" data-target=".bd-example-modal-lg">BOOK</button>
                                    <?php else: ?>
                                    <button id="<?php echo e($row->id); ?>" title="<?php echo e($row->user->id); ?>" message="now" class="btn btn-outline-success take-btn button-show-now" data-toggle="modal" data-target=".bd-example-modal-lg">BOOK NOW</button>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <button id="<?php echo e($row->id); ?>" title="<?php echo e($row->user->id); ?>" class="btn btn-outline-primary take-btn button-show" data-toggle="modal" data-target=".bd-example-modal-lg">BOOK</button>
                                    <?php endif; ?>
                                    <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
</div>
<?php endfor; ?>
</div>
<?php echo $__env->make('marketing.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('footer'); ?>
<script>
    $(document).ready(function() {
        $('#startdate,#enddate').datetimepicker({
            useCurrent: true,
            minDate: moment()
        });
        $.ajax({
            url: '/marketing/cabang',
            success: function(data) {
                let name = $.each(data.resource, function() {
                    $('.select').append(`<option value="${this.id}">${this.nama}</option>`)
                });
            }
        })
    })
    $('.button-show-now').click(function() {
        status = $(this).attr('message')
        var button = $(this).attr('id')
        var dokter = $(this).attr('title')
        $('#pasien_id').html('')

        $.ajax({
            url: `/marketing/jadwal/now/${button}/${dokter}`,
            success: (data) => {
                console.log(data)
                $('#jadwal_id').val(button)
                $('#dokter_id').val(`${data.dokter.id}`)
                $('#waktu_mulai').val(data.booking)
                $('#dokter_name').val(data.dokter.name)

            }
        })
    })
    $('.button-show').click(function() {
        status = $(this).attr('message')
        var button = $(this).attr('id')
        var dokter = $(this).attr('title')
        $('#pasien_id').html('')
        $.ajax({
            url: `/marketing/jadwal/${button}/${dokter}`,
            success: (data) => {
                console.log(data)
                $('#jadwal_id').val(button)


                $('#dokter_id').val(`${data.dokter.id}`)
                $('#waktu_mulai').val(data.booking)
                $('#dokter_name').val(data.dokter.name)

            }
        })
    })
    $('.pasienList').select2({
        placeholder: 'Select Customer',
        ajax: {
            url: `/marketing/where/customer`,
            processResults: function(data) {
                console.log(data)
                return {
                    results: data
                };
            },
            cache: true
        }
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/marketing/dashboard.blade.php ENDPATH**/ ?>