<ul>
    <li class="menu-title">Main</li>
    <li class="<?php echo e(request()->is('dashboard*') ? 'active' : ''); ?>">
        <a href="/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
    </li>
    <li class="<?php echo e(request()->is('admin/dokter*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.dokter.index')); ?>"><i class="fa fa-user-md"></i> <span>Dokter</span></a>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient-access')): ?>
    <li class="<?php echo e(request()->is('admin/pasien*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.pasien.index')); ?>"><i class="fa fa-wheelchair"></i> <span>Pasien</span></a>
    </li>
    <?php endif; ?>
    <li class="<?php echo e(request()->is('admin/appointments*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.appointments.index')); ?>"><i class="fa fa-calendar"></i> <span>Appointments</span></a>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-access')): ?>
    <li class="<?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.users.index')); ?>"><i class="fa fa-users"></i> <span>Master User</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cabang-access')): ?>
    <li class="<?php echo e(request()->is('admin/cabang*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.cabang.index')); ?>"><i class="fa fa-building"></i> <span>Master Cabang</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier-access')): ?>
    <li class="<?php echo e(request()->is('admin/supplier*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.supplier.index')); ?>"><i class="fa fa-building"></i> <span>Master Supplier</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase-access')): ?>
    <li class="<?php echo e(request()->is('admin/purchase*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.purchase.index')); ?>"><i class="fa fa-calculator"></i> <span>Master Purchase</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase-access')): ?>
    <li class="<?php echo e(request()->is('admin/transfer*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.transfer.index')); ?>"><i class="fa fa-calculator"></i> <span>Transfer Stok</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-access')): ?>
    <li class="<?php echo e(request()->is('admin/product*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.product.index')); ?>"><i class="fa fa-shopping-bag"></i> <span>Master Product</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-access')): ?>
    <li class="<?php echo e(request()->is('admin/service*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.service.index')); ?>"><i class="fa fa-stethoscope"></i> <span>Master Service</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment-access')): ?>
    <li class="<?php echo e(request()->is('admin/payments*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.payments.index')); ?>"><i class="fa fa-credit-card"></i> <span>Master Payments</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('status-access')): ?>
    <li class="<?php echo e(request()->is('admin/status*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.status.index')); ?>"><i class="fa fa-line-chart"></i> <span>Master Status</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voucher-access')): ?>
    <li class="<?php echo e(request()->is('admin/voucher*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.voucher.index')); ?>"><i class="fa fa-tags"></i> <span>Master Voucher</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('komisi-access')): ?>
    <li class="<?php echo e(request()->is('admin/komisi*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.komisi.index')); ?>"><i class="fa fa-money"></i> <span>Master Komisi</span></a>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('simbol-access')): ?>
    <li class="<?php echo e(request()->is('admin/simbol*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.simbol.index')); ?>"><i class="fa fa-question"></i> <span>Master Simbol</span></a>
    </li>
    <?php endif; ?>
    <li class="submenu">
        <a href="#"><i class="fa fa-user"></i> <span> Master Invoice </span> <span class="menu-arrow"></span></a>
        <ul style="display: none;">
            <li><a class="<?php echo e((request()->is('admin/holidays*')) ? 'active' : ''); ?>" href="<?php echo e(route('admin.holidays.index')); ?>">Holidays</a></li>
            <li><a class="<?php echo e((request()->is('admin/attendance*')) ? 'active' : ''); ?>" href="<?php echo e(route('admin.attendance.index')); ?>">Attendance</a></li>
        </ul>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report-access')): ?>
    <li class="submenu">
        <a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
        <ul style="display: none;">
            <li><a href="<?php echo e(route('admin.report.appoinment')); ?>"> Laporan Appointment </a></li>
            <li><a href="<?php echo e(route('admin.report.payment')); ?>"> Laporan Metode Pembayaran </a></li>
            <li><a href="<?php echo e(route('admin.report.komisi')); ?>"> Laporan Komisi </a></li>
            <li><a href="<?php echo e(route('admin.report.pasien')); ?>"> Laporan Pasien </a></li>
            <li><a href="<?php echo e(route('admin.report.perpindahan.pasien')); ?>"> Laporan Perpindahan Pasien </a></li>
            <li><a href="<?php echo e(route('admin.report.barang')); ?>"> Laporan Barang</a></li>
        </ul>
    </li>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
    <li class="submenu">
        <a href="#" class=""><i class="fa fa-cog"></i> <span> Settings </span> <span class="menu-arrow"></span></a>
        <ul style="display: none;">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-access')): ?>
            <li class="<?php echo e(request()->is('admin/setting*') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.setting.index')); ?>">Basic Setting</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-access')): ?>
            <li class="<?php echo e(request()->is('admin/permissions*') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.permissions.index')); ?>">Permissions</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles-access')): ?>
            <li class="<?php echo e(request()->is('admin/roles*') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.roles.index')); ?>">Roles</a></li>
            <?php endif; ?>
        </ul>
    </li>
    <?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>