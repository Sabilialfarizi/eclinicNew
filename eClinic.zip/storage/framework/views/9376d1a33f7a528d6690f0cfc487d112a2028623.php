

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="page-title">Report Pasien</h4>
    </div>
</div>

<form action="<?php echo e(route('admin.report.pasien')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row filter-row">
        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus select-focus focused">
                <label class="focus-label">Cabang</label>
                <select name="cabang" class="select floating select2" tabindex="-1" aria-hidden="true">
                    option disabled selected>Select Cabang</option>
                    <option <?php echo e(request('cabang') == 'all' ? 'selected' : ''); ?> value="all">Semua Cabang</option>
                    <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(request('cabang') == $cab->id ? 'selected' : ''); ?> value="<?php echo e($cab->id); ?>" required><?php echo e($cab->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus">
                <label class="focus-label">From</label>
                <div class="cal-icon">
                    <input class="form-control floating datetimepicker" type="text" name="from" required>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus">
                <label class="focus-label">To</label>
                <div class="cal-icon">
                    <input class="form-control floating datetimepicker" type="text" name="to" required>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <button type="submit" class="btn btn-success btn-block">Search</button>
            <!-- <?php if(request('metode')): ?>
            <a href="<?php echo e(route('admin.payment.export', request('metode'))); ?>" type="submit" class="btn btn-danger"><i class="fa fa-file-excel-o"></i> Export</a>
            <?php endif; ?> -->
        </div>
    </div>
</form>

<?php echo $__env->make('admin.report.pasien.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Pasien <?php echo e($cb ? " Cabang " . $cb->nama : "Semua Cabang"); ?>',
                messageTop: 'Tanggal <?php echo e($from); ?>  -  <?php echo e($to); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Pasien <?php echo e($cb ? "Cabang " . $cb->nama : "Semua Cabang"); ?>',
                messageTop: 'Tanggal <?php echo e($from); ?>  -  <?php echo e($to); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' =>'Report Pasien'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/report/pasien/index.blade.php ENDPATH**/ ?>