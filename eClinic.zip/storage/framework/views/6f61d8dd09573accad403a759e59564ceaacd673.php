

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-md-6">
        <h1 class="page-title">Edit Roles</h1>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-6">
        <form action="<?php echo e(route('admin.roles.update', $role->id)); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('admin.roles.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Roles'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>