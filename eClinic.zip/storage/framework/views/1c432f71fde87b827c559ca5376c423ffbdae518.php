

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">Cabang <?php echo e($cabang->nama); ?></h4>
    </div>

     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>

<div class="row">
    <div class="col-sm-4">
        <h4 class="page-title">List Harga Service</h4>
    </div>
    <div class="col-sm-8 col-9 text-right m-b-20">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cabang-create')): ?>
        <a href="/admin/price-service/<?php echo e($cabang->id); ?>/create" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Harga Service</a>
        <?php endif; ?>
    </div>

    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table table-bordered table-striped custom-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Service</th>
                        <th>Nama</th>
                        <th>Harga</th>
                        <th>Durasi</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($service->product->kode_barang); ?></td>
                        <td><?php echo e($service->product->nama_barang); ?></td>
                        <td>Rp. <?php echo number_format($service->harga, 0, ',', '.'); ?></td>
                        <td><?php echo e($service->product->durasi); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-edit')): ?>
                            <a href="/admin/price-service/<?php echo e($service->id); ?>/edit" class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-delete')): ?>
                            <form action="/admin/price/<?php echo e($service->id); ?>/destroy" method="post" style="display: inline;" class="delete-form">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row mt-5">
    <div class="col-sm-4 col-3">
        <h4 class="page-title">List Harga Produk</h4>
    </div>

    <div class="col-sm-8 col-9 text-right m-b-20">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cabang-create')): ?>
        <a href="/admin/price-product/<?php echo e($cabang->id); ?>/create" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Harga Produk</a>
        <?php endif; ?>
    </div>

    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table table-bordered table-striped custom-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Produk</th>
                        <th>Nama</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($product->product->kode_barang); ?></td>
                        <td><?php echo e($product->product->nama_barang); ?></td>
                        <td>Rp. <?php echo number_format($product->harga, 0, ',', '.'); ?></td>
                        <td><?php echo e($product->qty); ?></td>
                        <td>
                            <a href="/admin/price-product/<?php echo e($product->id); ?>/edit" class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-delete')): ?>
                            <form action="/admin/price/<?php echo e($product->id); ?>/destroy" method="post" style="display: inline;" class="delete-form">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Cabang'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/cabang/show.blade.php ENDPATH**/ ?>