<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/')); ?>img/favicon.ico">
    <title>Login - <?php echo e(\App\Setting::find(1)->web_name); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>css/style.css">
    <!--[if lt IE 9]>
		<script src="<?php echo e(asset('/')); ?>js/html5shiv.min.js"></script>
		<script src="<?php echo e(asset('/')); ?>js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
            <div class="account-center">
                <div class="account-box">
                    <form action="<?php echo e(route('login')); ?>" class="form-signin" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="account-logo">
                            <a href="/"><img src="<?php echo e(asset('/storage/' . \App\Setting::find(1)->logo)); ?>" alt=""></a>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group text-right">
                            <!-- <a href="forgot-password.html">Forgot your password?</a> -->
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary account-btn">Login</button>
                        </div>
                        <div class="text-center register-link">
                            <!-- Don’t have an account? <a href="register.html">Register Now</a> -->
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('/')); ?>js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/popper.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/app.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/auth/login.blade.php ENDPATH**/ ?>