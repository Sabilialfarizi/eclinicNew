

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="page-title">History Pemeriksaan - <?php echo e($customer->nama); ?></h4>
    </div>
</div>

<div class="row">
    <?php $__currentLoopData = $customer->booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header">
                <?php echo e($booking->no_booking); ?>

            </div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $booking->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-3">
                        <img src="<?php echo e(asset('/storage/' . $image->image)); ?>" class="rounded" alt="..." style="height: 220px; width: 220px; object-fit: cover; object-position: center;">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<!-- <script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan History Pembayaran Pasien',
                messageTop: '<?php echo e($customer->nama); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan History Pembayaran Pasien',
                messageTop: '<?php echo e($customer->nama); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });
</script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' =>'History Pemeriksaan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/patient/image.blade.php ENDPATH**/ ?>