<div class="form-group">
    <label>Name</label>
    <input type="text" name="name" id="name" class="form-control" value="<?php echo e($permission->key); ?>">
</div>

<div class="m-t-20 text-center">
    <button type="submit" class="btn btn-primary submit-btn"><i class="fa fa-save"></i> Save</button>
</div><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/permission/form.blade.php ENDPATH**/ ?>