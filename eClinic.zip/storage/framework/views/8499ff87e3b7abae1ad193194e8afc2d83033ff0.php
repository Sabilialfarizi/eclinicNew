

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="page-title">Attendance Sheet</h4>
    </div>
</div>

<form action="<?php echo e(route('admin.attendance.search')); ?>" method="GET" id="TheSubmitFormForFilterAttendance">
    <div class="row filter-row">
        <div class="col-sm-6 col-md-6">
            <div class="form-group form-focus">
                <label class="focus-label">Employee Name</label>
                <?php echo csrf_field(); ?>
                <input type="text" value="<?php echo e(old('pegawai')); ?>" class="form-control floating" name="pegawai">
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus select-focus">
                <label class="focus-label">Select Month</label>
                <select class="select floating" name="month" onchange="TheSubmitFormForFilterAttendance()">
                    <option value="">-</option>
                    <option <?php if($month == "01"): ?> selected <?php endif; ?> value="01">Jan</option>
                    <option <?php if($month == "02"): ?> selected <?php endif; ?> value="02">Feb</option>
                    <option <?php if($month == "03"): ?> selected <?php endif; ?> value="03">Mar</option>
                    <option <?php if($month == "04"): ?> selected <?php endif; ?> value="04">Apr</option>
                    <option <?php if($month == "05"): ?> selected <?php endif; ?> value="05">May</option>
                    <option <?php if($month == "06"): ?> selected <?php endif; ?> value="06">Jun</option>
                    <option <?php if($month == "07"): ?> selected <?php endif; ?> value="07">Jul</option>
                    <option <?php if($month == "08"): ?> selected <?php endif; ?> value="08">Aug</option>
                    <option <?php if($month == "09"): ?> selected <?php endif; ?> value="09">Sep</option>
                    <option <?php if($month == "10"): ?> selected <?php endif; ?> value="10">Oct</option>
                    <option <?php if($month == "11"): ?> selected <?php endif; ?> value="11">Nov</option>
                    <option <?php if($month == "12"): ?> selected <?php endif; ?> value="12">Dec</option>
                </select>
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus select-focus">
                <label class="focus-label">Select Year</label>
                <select class="select floating" name="year" onchange="TheSubmitFormForFilterAttendance()">
                    <option value="">-</option>
                    <option <?php if($year == '2023'): ?> selected <?php endif; ?>>2023</option>
                    <option <?php if($year == '2022'): ?> selected <?php endif; ?>>2022</option>
                    <option <?php if($year == '2021'): ?> selected <?php endif; ?>>2021</option>
                    <option <?php if($year == '2020'): ?> selected <?php endif; ?>>2020</option>
                    <option <?php if($year == '2019'): ?> selected <?php endif; ?>>2019</option>
                    <option <?php if($year == '2018'): ?> selected <?php endif; ?>>2018</option>
                    <option <?php if($year == '2017'): ?> selected <?php endif; ?>>2017</option>
                    <option <?php if($year == '2016'): ?> selected <?php endif; ?>>2016</option>
                    <option <?php if($year == '2015'): ?> selected <?php endif; ?>>2015</option>
                    <option <?php if($year == '2014'): ?> selected <?php endif; ?>>2014</option>
                    <option <?php if($year == '2013'): ?> selected <?php endif; ?>>2013</option>
                </select>
            </div>
        </div>
    </div>
</form>
<?php if($message = Session::get('error')): ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-danger">
            <?php echo e($message); ?>

        </div>
    </div>
</div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-success">
            <?php echo e($message); ?>

        </div>
    </div>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card shadow">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <div>
                        <a href="<?php echo e(route('admin.attendance.update_user', [$month,$year])); ?>" class="btn btn-info text-light btn-block" id="tombol-hapus" value="delete">Update User <?php echo e($year); ?> <?php echo e($month); ?></a>
                    </div>
                    <div>
                        <h2><span class="badge badge-success"><?php echo e($year); ?>-<?php echo e($month); ?>-<?php echo e($day); ?></span></h2>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table border table-bordered table-hover">
                        <tr class="text-center bg-success">
                            <th colspan="<?php echo e(3 + $day); ?>">
                                <h5 class="text-light">Attendance - <?php echo e($year); ?> <?php echo e($month); ?></h5>
                            </th>
                        </tr>
                        <tr class="text-center bg-info">
                            <th class="text-light">#</th>
                            <th class="text-light">Pegawai</th>
                            <th class="text-light">Role</th>
                            <?php for($i = 1;$i <= $day;$i++): ?> <th class="text-light"><?php echo e($i); ?></th> <?php endfor; ?>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-center">
                            <td><?php echo e($data->id); ?></td>
                            <td><button type="button" id="<?php echo e($data->id); ?>" year="<?php echo e($year); ?>" month="<?php echo e($month); ?>" class="btn btn-outline-primary button-show" data-toggle="modal" data-target=".bd-example-modal-lg"><?php echo e($data->name); ?></button></td>
                            <td>
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $data->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($role->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <?php for($i = 1; $i <= $day; $i++): ?> <td>
                                <?php $__currentLoopData = $data->jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Carbon\Carbon::parse($row->tanggal)->format('Y') == $year): ?>
                                        <?php if(Carbon\Carbon::parse($row->tanggal)->format('m') == $month): ?>
                                            <?php if(Carbon\Carbon::parse($row->tanggal)->format('d') == $i): ?>
                                                <?php if($row->shift->kode == 'SF1'|| $row->shift->kode == 'SF2'): ?>
                                                <i class="fa fa-check text-success"><?php echo e($row->shift->kode); ?></i>
                                                <?php else: ?>
                                                    <?php if($row->shift->kode == 'L'): ?>
                                                    <i class="fa fa-close text-danger"><?php echo e($row->shift->kode); ?></i>
                                                    <?php else: ?>
                                                    <i class="fa fa-info text-warning"><?php echo e($row->shift->kode); ?></i>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $holiday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Carbon\Carbon::parse($list->holiday_date)->format('d') == $i): ?>
                                <i class="fa fa-close text-danger"><?php echo e($list->title); ?></i>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            <?php endfor; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="40">
                                <div class="alert alert-warning text-center">Data Kosong</div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.attendance.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script>
    const Year = function()
    {
        let start = new Date().getFullYear();
        for (let i = start; i > start - 10; i--){
            console.log(i)
        }
    }
    Year()
    function TheSubmitFormForFilterAttendance(){
        $('#TheSubmitFormForFilterAttendance').submit()
    }
    $('.button-show').click(function() {
        event.preventDefault()
        let id = $(this).attr('id');
        let year = $(this).attr('year')
        let month = $(this).attr('month')
        
        $('#tombol-hapus').attr('year', year);
        $('#tombol-hapus').attr('month', month);
        $('#tombol-hapus').attr('dataID', id);

        $.ajax({
            url: `/admin/attendance/${id}`,
            success: function(result) {
                $("#name_user").val(result.name);
                $("#cabang_id").val(result.cabang_id)
                $('#cabang').val(result.cabang)
                $('#ruangan_id').html('')
                $.each(result.ruangan, function() {
                    $('#ruangan_id').append(`<option value="${this.id}">${this.nama_ruangan}</option>`)
                })
            }
        });

        console.log($('#tombol-hapus-attendance').attr('href', `/admin/attendance/reset/${id}/${year}/${month}`))
        $('#id').val(id)
        $('#show-data').modal('show')
        $('#table-jadwal').DataTable({
            destroy: true,
            processing: true,
            serverSide: true,
            ajax: ({
                url: `/admin/attendance/edit/${id}/${year}/${month}`,
                type: 'get',
                error: err => {
                    alert(err)
                }
            }),
            columns: [{
                    name: "id",
                    data: "id"
                },
                {
                    name: "tanggal",
                    data: "tanggal"
                },
                {
                    name: "kode",
                    data: "kode"
                },
                {
                    name: "cabang",
                    data: "cabang"
                },
                {
                    name: "ruang",
                    data: "ruang"
                },
                {
                    data: "SF1"
                },
                {
                    data: "SF2"
                },
                {
                    data: 'L'
                }
            ]
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Attendance'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/attendance/index.blade.php ENDPATH**/ ?>