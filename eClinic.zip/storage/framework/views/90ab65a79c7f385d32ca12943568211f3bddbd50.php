
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-5 col-4">
        <h4 class="page-title">Purchase</h4>
    </div>
    <div class="col-sm-7 col-8 text-right m-b-30">
        <div class="btn-group btn-group-sm">
            <button class="btn btn-white">CSV</button>
            <button class="btn btn-white">PDF</button>
            <button class="btn btn-white"><i class="fa fa-print fa-lg"></i> Print</button>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card shadow" id="card">
            <div class="card-body">
                <div class="row custom-invoice">
                    <div class="col-4 col-sm-4 m-b-20">
                        <img src="<?php echo e(asset('/storage/' . \App\Setting::find(1)->logo)); ?>" class="inv-logo" alt="">
                        <table>
                            <tr>
                                <td width="150px">Invoice</td>
                                <td> : </td>
                                <td><b><?php echo e($purchase->invoice); ?></b></td>
                            </tr>
                            <tr>
                                <td width="150px">Tanggal</td>
                                <td> : </td>
                                <td><?php echo e(Carbon\Carbon::parse($purchase->created_at)->format('d/m/Y H:i:s')); ?></td>
                            </tr>
                            <tr>
                                <td width="150px">Supplier</td>
                                <td> : </td>
                                <td><?php echo e($purchase->supplier->nama); ?></td>
                            </tr>
                            <tr>
                                <td width="150px">Admin</td>
                                <td> : </td>
                                <td><?php echo e($purchase->admin->name); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-hover border" id="table-show">
                                <tr class="bg-success">
                                    <th class="text-light">NO</th>
                                    <th class="text-light">ITEM</th>
                                    <th class="text-light">QTY</th>
                                    <th class="text-light">HARGA BELI</th>
                                    <th class="text-light">TOTAL</th>
                                </tr>
                                <tbody>
                                    <?php
                                    $total = 0
                                    ?>
                                    <?php $__currentLoopData = App\Purchase::where('invoice', $purchase->invoice)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($barang->barang->nama_barang); ?></td>
                                        <td><?php echo e($barang->qty); ?></td>
                                        <td>Rp. <?php echo number_format($barang->harga_beli, 0, ',', '.'); ?></td>
                                        <td>Rp. <?php echo number_format($barang->total, 0, ',', '.'); ?></td>
                                    </tr>
                                    <?php
                                    $total += $barang->total
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4">Total Pembelian : </td>
                                        <td><b>Rp. <?php echo number_format($total, 0, ',', '.'); ?></b></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Create Purchase'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/purchase/show.blade.php ENDPATH**/ ?>