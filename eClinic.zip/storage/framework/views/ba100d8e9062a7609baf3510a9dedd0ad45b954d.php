

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="page-title">Detail Product <?php echo e($product->nama_barang); ?></h4>
    </div>
</div>

<form action="<?php echo e(route('admin.product.show', $product->id)); ?>" method="get">
    <?php echo csrf_field(); ?>
    <div class="row filter-row">
        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus">
                <label class="focus-label">From</label>
                <div class="cal-icon">
                    <input class="form-control floating datetimepicker" type="text" name="from" required>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="form-group form-focus">
                <label class="focus-label">To</label>
                <div class="cal-icon">
                    <input class="form-control floating datetimepicker" type="text" name="to" required>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <button type="submit" class="btn btn-success btn-block">Search</button>
        </div>
    </div>
</form>

<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered custom-table report" width="100%">
                <thead>
                    <tr>
                        <th style="text-align: center;">No</th>
                        <th>Supllier</th>
                        <th>Customer</th>
                        <th>Before</th>
                        <th>In</th>
                        <th>Out</th>
                        <th>Last Stok</th>
                        <th>Waktu</th>
                        <th>Admin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $product->inout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($inout->supplier->nama ?? '-'); ?></td>
                        <td>
                            <?php if($inout->cabang_id): ?>
                            <?php echo e($inout->cabang->nama ?? '-'); ?>

                            <?php endif; ?>
                            <?php if($inout->customer_id): ?>
                            <?php echo e($inout->customer->nama ?? '-'); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($inout->in ? $inout->last_stok - $inout->in : $inout->last_stok - $inout->out); ?>

                        </td>
                        <td><?php echo e($inout->in ?? '-'); ?></td>
                        <td><?php echo e($inout->out ?? '-'); ?></td>
                        <td><?php echo e($inout->last_stok ?? '-'); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($inout->created_at)->format('d/m/Y H:i:s')); ?></td>
                        <td><?php echo e($inout->admin->name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td>Total : </td>
                        <td></td>
                        <td></td>
                        <td><?php echo e($product->inout->sum('last_stok') - ($product->inout->sum('out') + $product->inout->sum('in')) ?? 0); ?></td>
                        <td><?php echo e($product->inout->sum('in') ?? 0); ?></td>
                        <td><?php echo e($product->inout->sum('out') ?? 0); ?></td>
                        <td><?php echo e($product->inout->sum('last_stok') ?? 0); ?></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $('.report').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'copy',
                className: 'btn-default',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'excel',
                className: 'btn-default',
                title: 'Laporan Product <?php echo e($product->nama_barang); ?> ',
                messageTop: 'Tanggal <?php echo e(request("from") ?? Carbon\Carbon::now()->format("d/m/Y H:i:s")); ?>  -  <?php echo e(request("to") ?? ""); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                className: 'btn-default',
                title: 'Laporan Product <?php echo e($product->nama_barang); ?> ',
                messageTop: 'Tanggal <?php echo e(request("from") ?? Carbon\Carbon::now()->format("d/m/Y H:i:s")); ?>  -  <?php echo e(request("to") ?? ""); ?>',
                footer: true,
                exportOptions: {
                    columns: ':visible'
                }
            },
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' =>'Detail Product - ' . $product->nama_barang], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/product/show.blade.php ENDPATH**/ ?>