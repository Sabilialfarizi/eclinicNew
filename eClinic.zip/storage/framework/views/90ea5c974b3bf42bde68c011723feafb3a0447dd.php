<ul>
    <li class="menu-title">Main</li>
    <li class="<?php echo e(request()->is('dashboard*') ? 'active' : ''); ?>">
        <a href="/dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
    </li>
    <li class="<?php echo e((request()->is('marketing/pricelist*')) ? 'active' : ''); ?>">
        <a href="<?php echo e(route('marketing.pricelist.index')); ?>"><i class="fa fa-wheelchair"></i> <span>Pricelist</span></a>
    </li>
    <li class="<?php echo e((request()->is('marketing/doctor*')) ? 'active' : ''); ?>">
        <a href="<?php echo e(route('marketing.doctor.index')); ?>"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
    </li>
    <li class="<?php echo e((request()->is('marketing/patient*')) ? 'active' : ''); ?>">
        <a href="<?php echo e(route('marketing.patient.index')); ?>"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
    </li>
    <li class="<?php echo e((request()->is('marketing/appointments*')) ? 'active' : ''); ?>">
        <a href="<?php echo e(route('marketing.appointments.index')); ?>"><i class="fa fa-calendar"></i> <span>Appointments</span></a>
    </li>
</ul><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/components/marketing/sidebar.blade.php ENDPATH**/ ?>