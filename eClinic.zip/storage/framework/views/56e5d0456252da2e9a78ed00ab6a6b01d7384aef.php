<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered custom-table report" width="100%">
                <thead>
                    <tr>
                        <th style="text-align: center;">No</th>
                        <th>Nama</th>
                        <th>No Telp</th>
                        <th>Email</th>
                        <th>TTL</th>
                        <th>JK</th>
                        <th>Suku</th>
                        <th>Alamat</th>
                        <th>Pekerjaan</th>
                        <th>Marketing</th>
                        <th>Cabang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($pas->nama); ?></td>
                        <td><?php echo e($pas->no_telp); ?></td>
                        <td><?php echo e($pas->email); ?></td>
                        <td><?php echo e($pas->tempat_lahir); ?>, <?php echo e($pas->tgl_lahir); ?></td>
                        <td><?php echo e($pas->jk); ?></td>
                        <td><?php echo e($pas->suku); ?></td>
                        <td><?php echo e($pas->alamat); ?></td>
                        <td><?php echo e($pas->pekerjaan); ?></td>
                        <td><?php echo e($pas->user->name); ?></td>
                        <td><?php echo e($pas->cabang->nama); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/report/pasien/table.blade.php ENDPATH**/ ?>