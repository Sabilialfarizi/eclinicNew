

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center text-center">
    <div class="col-md-6">
        <h1 class="page-title">Edit Supplier</h1>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-sm-6">
        <form action="<?php echo e(route('admin.supplier.update', $supplier->id)); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('admin.supplier.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => 'Supplier'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eclinic\resources\views/admin/supplier/edit.blade.php ENDPATH**/ ?>